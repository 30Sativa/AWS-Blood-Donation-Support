﻿namespace BloodDonationSupport.IntergrationTests
{
    public class Class1
    {

    }
}
