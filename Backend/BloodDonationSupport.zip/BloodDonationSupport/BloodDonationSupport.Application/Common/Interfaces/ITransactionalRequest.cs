﻿namespace BloodDonationSupport.Application.Common.Interfaces
{
    public interface ITransactionalRequest
    {
    }
}