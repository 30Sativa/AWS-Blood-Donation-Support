﻿namespace BloodDonationSupport.UnitTests
{
    public class Class1
    {

    }
}
